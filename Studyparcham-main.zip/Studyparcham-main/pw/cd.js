const tokens = [
    "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE3ODQwMTkzNzcuODQ1LCJkYXRhIjp7Il9pZCI6IjY2ZDljZTQ0NjQ5NjY4YmU5Y2Y5YmEzZSIsInVzZXJuYW1lIjoiNzg4OTMzOTE1MSIsImZpcnN0TmFtZSI6Ik11ZGFzaXIiLCJsYXN0TmFtZSI6Ik11c2h0YXEiLCJvcmdhbml6YXRpb24iOnsiX2lkIjoiNWViMzkzZWU5NWZhYjc0NjhhNzlkMTg5Iiwid2Vic2l0ZSI6InBoeXNpY3N3YWxsYWguY29tIiwibmFtZSI6IlBoeXNpY3N3YWxsYWgifSwicm9sZXMiOlsiNWIyN2JkOTY1ODQyZjk1MGE3NzhjNmVmIl0sImNvdW50cnlHcm91cCI6IklOIiwidHlwZSI6IlVTRVIifSwianRpIjoic19YaFpyZEZURUdLUC1jMjRYenZYQV82NmQ5Y2U0NDY0OTY2OGJlOWNmOWJhM2UiLCJpYXQiOjE3ODM0MTQ1Nzd9.H2FqpWlBRduomNEye6uLIfr-2H_hVTBgX51kEqMvXF0",
    "YOUR_TOKEN_2",
    // Add all your tokens here
];

const PROXY_URL = "https://pw-proxy-seven.vercel.app/api/proxy"; // Your worker URL

async function auditTokens() {
    for (const token of tokens) {
        console.log(`Checking token: ${token.substring(0, 10)}...`);
        
        try {
            const response = await fetch(`${PROXY_URL}?target_url=https://api.penpencil.co/v3/batches/my-batches`, {
                method: 'GET',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'client-id': '5eb393ee95fab7468a79d189' 
                }
            });
            
            const json = await response.json();
            
            if (json.success && json.data) {
                const batchNames = json.data.map(b => b.name);
                console.log(`✅ Token active! Batches: ${batchNames.join(', ')}`);
            } else {
                console.log("❌ Token invalid or no batches found.");
            }
        } catch (e) {
            console.error("Error checking token:", e.message);
        }
    }
}

auditTokens();

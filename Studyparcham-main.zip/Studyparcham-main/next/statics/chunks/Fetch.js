        // --- OPTIMIZED LIGHTWEIGHT BATCH LOADING ENGINE ---
        let globalBatchesCache = [];
        const blockedBatchNames = ['arjuna jee 2027.', '']; 

        async function fetchBatches(isNewSearch = false) {
            let statusEl = document.getElementById('load-status');
            let btn = document.querySelector('#load-more-container button');
            
            if (isNewSearch) {
                currentPage = 1;
                document.getElementById('all-batch-grid').innerHTML = '';
                if(statusEl) statusEl.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Searching...';
            } else {
                if(btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            }

            try {
                // 1. Fetch both static catalog and custom KV batches simultaneously if cache is empty
                if (globalBatchesCache.length === 0) {
                    let mainBatches = [];
                    let kvBatches = [];

                    try {
                        let res = await fetch('/data/all_batches.json');
                        let parsedData = JSON.parse(await res.text());
                        let rawBatches = Array.isArray(parsedData) ? parsedData : (parsedData.data || []);
                        mainBatches = rawBatches.map(b => ({
                            _id: b.id || b._id,
                            name: b.name,
                            previewImage: b.imageUrl || b.previewImage
                        }));
                    } catch(e) { console.error("Static JSON file fetch failed", e); }

                    try {
                        let kvRes = await fetch('/api/batches'); // Your backend handles returning KV cache here
                        let parsedKV = JSON.parse(await kvRes.text());
                        let rawKV = Array.isArray(parsedKV) ? parsedKV : (parsedKV.data || []);
                        kvBatches = rawKV.map(b => ({
                            _id: b.id || b._id,
                            name: b.name,
                            previewImage: b.imageUrl || b.previewImage
                        }));
                    } catch(e) { console.log("KV additions are empty or uninitialized"); }

                    // Merge databases locally (KV entries take priority)
                    let uniqueMap = new Map();
                    [...kvBatches, ...mainBatches].forEach(b => {
                        if(b && b._id && !uniqueMap.has(b._id)) {
                            uniqueMap.set(b._id, b);
                        }
                    });
                    globalBatchesCache = Array.from(uniqueMap.values());
                }

                // 2. High-Speed Local Filter
                let searchTerm = (currentSearchTerm || '').toLowerCase().trim();
                let filteredBatches = globalBatchesCache.filter(b => {
                    let bName = (b.name || '').toLowerCase().trim();
                    let bId = (b._id || '').toLowerCase();
                    
                    if (blockedBatchNames.includes(bName)) return false; 
                    if (!searchTerm) return true; 
                    
                    return bName.includes(searchTerm) || bId === searchTerm;
                });

                // 3. Local Pagination
                const limit = 20;
                const total = filteredBatches.length;
                const offset = (currentPage - 1) * limit;
                const paginatedBatches = filteredBatches.slice(offset, offset + limit);
                
                // 4. Render
                if (paginatedBatches.length === 0 && isNewSearch) {
                    document.getElementById('all-batch-grid').innerHTML = '<div class="col-12 text-center p-5 text-muted"><i class="fas fa-search fa-2x mb-3"></i><br>No batches found.</div>';
                } else {
                    paginatedBatches.forEach(b => {
                        fetchedBatchesMap.set(b._id, b); 
                        renderSingleBatch(b);
                    });
                }

                // 5. Update UI Controls
                let loadMoreContainer = document.getElementById('load-more-container');
                if (loadMoreContainer) {
                    if ((currentPage * limit) >= total) {
                        loadMoreContainer.style.display = 'none';
                    } else {
                        loadMoreContainer.style.display = 'block';
                        if(btn) btn.innerHTML = '<i class="fas fa-sync-alt me-2"></i> Load More';
                    }
                }
                if(statusEl) statusEl.innerHTML = '';

            } catch(e) {
                console.error("Search Engine Error:", e);
                if(statusEl) statusEl.innerHTML = `<i class="fas fa-exclamation-triangle text-danger"></i> Failed`;
            }
        }

        function loadNextPage() { currentPage++; fetchBatches(false); }

        function handleSearchInput() {
            clearTimeout(searchTimeout);
            currentSearchTerm = document.getElementById('batch-search').value;
            searchTimeout = setTimeout(() => { fetchBatches(true); }, 500); 
        }

        function renderSingleBatch(b) {
            const grid = document.getElementById('all-batch-grid');
            let thumb = b.previewImage || "https://store.pw.live/footer-logo.svg";
            let safeName = (b.name || "").replace(/'/g, "\\'");
            let btnText = enrolledBatches.includes(b._id) ? 'Study' : 'View Details';

            let html = `
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card-custom" onclick="handleEnroll('${b._id}', '${safeName}')">
                        <img src="${thumb}" class="batch-thumb" loading="lazy">
                        <div class="card-body-custom">
                            <div class="title-text mt-2">${b.name}</div>
                            <button class="btn btn-dark w-100 mt-auto" style="font-weight: 600;">${btnText}</button>
                        </div>
                    </div>
                </div>
            `;
            grid.insertAdjacentHTML('beforeend', html);
        }

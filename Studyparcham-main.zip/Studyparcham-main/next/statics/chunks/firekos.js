
  const firebaseConfig = {
  apiKey: "AIzaSyCo_xHdl8D_rlJF1pPWg3-IrUn3dAYohEA",
  authDomain: "pwzero-database-ced90.firebaseapp.com",
  databaseURL: "https://pwzero-database-ced90-default-rtdb.firebaseio.com",
  projectId: "pwzero-database-ced90",
  storageBucket: "pwzero-database-ced90.firebasestorage.app",
  messagingSenderId: "142801934851",
  appId: "1:142801934851:web:57eaf24f03d85378778c36",
  measurementId: "G-T33D1MZWMR"
};


    firebase.initializeApp(firebaseConfig);
    const auth = firebase.auth();
    const db = firebase.firestore();
    
    // Global variable to hold logged-in user data
    let currentUserDoc = null;


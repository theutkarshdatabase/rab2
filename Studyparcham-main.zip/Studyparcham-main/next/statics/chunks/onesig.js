window.OneSignalDeferred = window.OneSignalDeferred || [];
      OneSignalDeferred.push(async function(OneSignal) {
        // 1. Initialize OneSignal (Removed the notifyButton to hide the bell icon)
        await OneSignal.init({
          appId: "c7b1128d-2b7d-47b7-8d7f-d73485b9be0b",
          safari_web_id: "web.onesignal.auto.4d177f4c-af32-40a6-bcd9-e75371e6c146",
        });

        // 2. Automatically show the prompt on page load if not already granted
        if (OneSignal.Notifications.permission !== "granted") {
            await OneSignal.Slidedown.promptPush();
        }
      });

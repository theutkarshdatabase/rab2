function decryptApiResponse(encryptedBase64) {
  const decipher = crypto.createDecipheriv(
    "aes-128-cbc",
    Buffer.from(dec, "utf8"),
    Buffer.from(kiv, "utf8")
  );

  let decrypted = decipher.update(
    Buffer.from(encryptedBase64, "base64"),
    undefined,
    "utf8"
  );
  decrypted += decipher.final("utf8");

  return JSON.parse(decrypted);
}

/**
 * Helper: upstream ko call karo same headers ke saath
 * Aur decrypted data return karo
 */
async function fetchAndDecryptContentDetails(reqHeaders, content_id, course_id) {
  const url = new URL("https://course.nexttoppers.com/course/content-details");
  url.searchParams.set("content_id", String(content_id));
  url.searchParams.set("course_id", String(course_id));

  // Jo headers aapke request me aaye, unko forward karna
  const forwardHeaders = {};
  for (const [key, value] of Object.entries(reqHeaders)) {
    const lower = key.toLowerCase();
    if (lower === "host" || lower === "connection" || lower === "content-length") {
      continue;
    }
    forwardHeaders[key] = value;
  }

  const res = await fetch(url.toString(), {
    method: "GET",
    headers: forwardHeaders,
  });

  if (!res.ok) {
    throw new Error(`Upstream error: ${res.status} ${res.statusText}`);
  }

  const json = await res.json();

  // Format assume: { success: true, data: "<encrypted base64>" } 
  // ya { success: true, data: { ... } }
  if (!json || json.success !== true || !json.data) {
    return json; // maybe already decrypted / different format
  }

  let decryptedData;
  if (typeof json.data === "string") {
    decryptedData = decryptApiResponse(json.data);
  } else {
    decryptedData = json.data;
  }

  return {
    success: true,
    data: decryptedData,
  };
}

//sdasdaasdadsadas


/*
 * Main endpoint – frontend iss ko call karega
 *
 * POST /api/content-details
 * body: { content_id, course_id }
 */
app.post("/api/content-details", async (req, res) => {
  try {
    const { content_id, course_id } = req.body || {};

    if (!content_id || !course_id) {
      return res.status(400).json({
        success: false,
        error: "content_id and course_id required",
      });
    }

    const reqHeaders = req.headers;

    const decrypted = await fetchAndDecryptContentDetails(
      reqHeaders,
      content_id,
      course_id
    );

    // CORS
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Content-Type, Authorization, Cookie, X-Requested-With"
    );
    res.setHeader(
      "Access-Control-Allow-Methods",
      "GET, POST, OPTIONS"
    );

    return res.json(decrypted);
  } catch (err) {
    console.error("Backend decrypt error:", err);
    return res.status(500).json({
      success: false,
      error: String(err.message || err),
    });
  }
});


  //wrewfdsfdsf






// --- Start server ---

// OPTIONS preflight
// GET /api/content-details?content_id=...&course_id=...
app.get("/api/content-details", async (req, res) => {
  try {
    const content_id = req.query.content_id;
    const course_id = req.query.course_id;

    if (!content_id || !course_id) {
      return res.status(400).json({
        success: false,
        error: "content_id and course_id required",
      });
    }

    const reqHeaders = req.headers;

    const decrypted = await fetchAndDecryptContentDetails(
      reqHeaders,
      content_id,
      course_id
    );

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Content-Type, Authorization, Cookie, X-Requested-With"
    );
    res.setHeader(
      "Access-Control-Allow-Methods",
      "GET, POST, OPTIONS"
    );

    return res.json(decrypted);
  } catch (err) {
    console.error("Backend decrypt error (GET):", err);
    return res.status(500).json({
      success: false,
      error: String(err.message || err),
    });
  }
});


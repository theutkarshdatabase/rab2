// ==========================================================
// STUDYPARCHAM PREMIUM ENGINE (Nexttoppers Edition)
// Flicker-Free | Advanced Enrollment UI | Flawless Routing
// ==========================================================

const SP_PROXY = 'https://sp-api-five.vercel.app/api/v1/proxy'; 
const FALLBACK_IMG = "https://i.ibb.co/dJbZq97B/2671188-1-logo.jpg";

const API = {
    OVERVIEW: 'https://course.nexttoppers.com/course/course-details',
    CONTENT: 'https://course.nexttoppers.com/course/all-content',
    MEDIA: 'https://course.nexttoppers.com/course/content-details'
};

// 🚨 STRICT VIP HEADERS
const NT_HEADERS = {
    'accept': 'application/json, text/plain, */*',
    'app_id': '1770981347',
    'authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoyNzg1NDU2LCJhcHBfaWQiOiIxNzcwOTgxMzQ3IiwiZGV2aWNlX2lkIjoiNGJhYjg0M2YtNGIzMi00MzRiLTkxNDAtN2M4MjY2ZTY1NzA0IiwicGxhdGZvcm0iOiIzIiwidXNlcl90eXBlIjoxLCJpYXQiOjE3ODMwMTk1NzQsImV4cCI6MTc4NTYxMTU3NH0.HVnc_3hxsr3l3ObYZDjQXKDmwdy8xiNv0rKlWVsj_6w',
    'content-type': 'application/json',
    'origin': 'https://nexttoppers.com',
    'platform': '3',
    'referer': 'https://nexttoppers.com/',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
    'user_id': '682065',
    'version': '1'
};

let currentCourseId = null;
let folderHistory = [];
window.masterBatches = [];

// ==========================================
// 🛡️ ENROLLMENT SYSTEM (LOCAL STORAGE)
// ==========================================
function getEnrolledBatches() {
    return JSON.parse(localStorage.getItem('nt_enrolled') || '[]');
}

window.enrollBatch = function(id, event) {
    event.stopPropagation(); // Prevents clicking the card background
    let enrolled = getEnrolledBatches();
    if(!enrolled.includes(id)) {
        enrolled.push(id);
        localStorage.setItem('nt_enrolled', JSON.stringify(enrolled));
        
        // Re-render UI immediately
        window.handleSearch(); 
        if(document.getElementById('my-batches-section').style.display === 'block') {
            window.renderMyBatches();
        }
        
        // Brief toast/alert
        alert("Success! You are now enrolled in this batch.");
    }
}

// ==========================================
// 🕒 ACCURATE TIME ENGINE
// ==========================================
function formatIST(unixSeconds) {
    let sec = parseInt(unixSeconds);
    if (!sec || isNaN(sec) || sec <= 0) return "Time not set";
    const date = new Date(sec * 1000);
    return date.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' });
}

function getTimeDiffStr(unixSeconds) {
    let sec = parseInt(unixSeconds);
    if (!sec || isNaN(sec) || sec <= 0) return "Soon";
    
    const now = Date.now();
    const target = sec * 1000;
    const diff = target - now;
    
    if (diff <= 0) return "Waiting to start"; 
    
    const h = Math.floor(diff / (1000 * 60 * 60));
    const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

// ==========================================
// 🚀 PROXY FETCHER
// ==========================================
async function engineFetch(targetUrl, methodToTry, payload = null) {
    try {
        const reqBody = { target_url: targetUrl, method: methodToTry, headers: NT_HEADERS };
        if (payload && methodToTry === 'POST') reqBody.payload = payload;

        const response = await fetch(SP_PROXY, {
            method: 'POST', 
            headers: { 'Content-Type': 'application/json', 'app_id': NT_HEADERS.app_id, 'authorization': NT_HEADERS.authorization, 'user_id': NT_HEADERS.user_id, 'platform': NT_HEADERS.platform, 'version': NT_HEADERS.version },
            body: JSON.stringify(reqBody)
        });
        
        const text = await response.text();
        try {
            const jsonStart = text.indexOf('{');
            const jsonEnd = text.lastIndexOf('}');
            if (jsonStart !== -1 && jsonEnd !== -1) {
                return JSON.parse(text.substring(jsonStart, jsonEnd + 1));
            }
        } catch(e) {}
        return null;
    } catch (e) { return null; }
}

// ==========================================
// 1. INSTANT LOCAL BATCH LOADER (From JSON)
// ==========================================
window.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('new-batches');
    if (container) container.innerHTML = '<div class="text-center w-100 py-5" style="grid-column: 1/-1;"><i class="fas fa-circle-notch fa-spin fa-2x text-primary"></i><p class="mt-2 text-muted" style="font-weight: 600;">Loading Master Database...</p></div>'; 
    
    const loadBtn = document.getElementById('load-more-btn');
    if (loadBtn) loadBtn.style.display = 'none';

    loadLocalBatches();
});

async function loadLocalBatches() {
    try {
        const response = await fetch('all_batches.json');
        const rawData = await response.json();
        
        window.masterBatches = rawData.map(batch => ({
            id: batch.course_id,
            title: batch.batch_name,
            thumb: batch.thumbnail && batch.thumbnail.trim() !== "" ? batch.thumbnail : FALLBACK_IMG,
            price: parseFloat(batch.price),
            mrp: parseFloat(batch.mrp)
        }));

        const loader = document.getElementById('loaderContainer'); 
        if(loader) loader.style.opacity = '0';

        window.handleSearch(); 
    } catch (error) {
        console.error("Failed to fetch all_batches.json:", error);
        document.getElementById('new-batches').innerHTML = '<div class="text-center w-100 py-5" style="grid-column: 1/-1; color: #ef4444; font-weight: bold;">Failed to load batches. Ensure all_batches.json is uploaded in the root folder.</div>';
    }
}

window.renderNextBatchChunk = function() {}; 

// ==========================================
// 2. UI GENERATORS
// ==========================================
function getBatchCardHtml(batch) {
    const isEnrolled = getEnrolledBatches().includes(batch.id);
    
    const btnHtml = isEnrolled 
        ? `<button class="adv-btn adv-btn-primary" onclick="openCourse(${batch.id})"><i class="fas fa-layer-group"></i> Explore Batch</button>`
        : `<button class="adv-btn adv-btn-gold" onclick="enrollBatch(${batch.id}, event)"><i class="fas fa-lock-open"></i> Enroll Now - ₹${batch.price}</button>`;

    return `
        <div class="adv-card animate-slide-up">
            <div class="adv-thumb-wrapper">
                <img src="${batch.thumb}" onerror="this.src='${FALLBACK_IMG}'" alt="Course Thumbnail">
            </div>
            <div class="adv-card-content">
                <h3 class="adv-title" title="${batch.title}">${batch.title}</h3>
                <div style="margin-top: auto;">
                    ${isEnrolled ? '<div class="adv-price" style="font-size:14px; margin-bottom:15px; color:#10b981;"><i class="fas fa-check-circle me-1"></i> Enrolled</div>' : `<div class="adv-price">₹${batch.price}</div>`}
                    ${btnHtml}
                </div>
            </div>
        </div>`;
}

window.handleSearch = function() {
    const term = document.getElementById('search-input').value.toLowerCase();
    const container = document.getElementById('new-batches');
    
    let searchHtml = "";
    window.masterBatches.filter(b => b.title.toLowerCase().includes(term)).forEach(b => {
        searchHtml += getBatchCardHtml(b);
    });
    
    container.innerHTML = searchHtml || `<div class="text-center w-100 py-5" style="grid-column: 1/-1;"><p style="color: var(--text-muted); font-weight: 600;">No batches found matching "${term}".</p></div>`;
}

window.renderMyBatches = function() {
    const container = document.getElementById('my-batches-container');
    const enrolledIds = getEnrolledBatches();
    const enrolledBatches = window.masterBatches.filter(b => enrolledIds.includes(b.id));
    
    if(enrolledBatches.length === 0) {
        container.innerHTML = `
            <div class="text-center w-100 py-5" style="grid-column: 1/-1;">
                <i class="fas fa-folder-open fa-3x mb-3 text-muted"></i>
                <p style="color: var(--text-muted); font-weight: 600;">You haven't enrolled in any batches yet.</p>
                <button class="adv-btn adv-btn-primary mt-3" style="max-width: 250px; margin: 0 auto;" onclick="showSection('home-section')">Browse Premium Courses</button>
            </div>`;
        return;
    }
    
    let html = "";
    enrolledBatches.forEach(b => { html += getBatchCardHtml(b); });
    container.innerHTML = html;
}

window.openCourse = async function(courseId) {
    currentCourseId = courseId;
    const courseData = window.masterBatches.find(b => b.id == courseId);
    
    document.getElementById('main-app').style.display = 'none';
    document.getElementById('detail-view').style.display = 'block';
    document.getElementById('course-title').innerText = courseData ? courseData.title : 'Course Details';
    
    const overviewContainer = document.getElementById('overview');
    overviewContainer.innerHTML = '<div class="text-center py-5"><i class="fas fa-circle-notch fa-spin fa-2x text-primary"></i><p class="mt-2" style="color: var(--text-muted);">Fetching Course Details from API...</p></div>';

    window.scrollTo(0, 0);
    
    fetchLiveFeed(courseId);
    folderHistory = [{ id: "0", name: "Root Folder" }];
    fetchFolderContent("0");

    try {
        const data = await engineFetch(API.OVERVIEW, 'POST', { course_id: String(courseId), parent_id: "0" });
        if (data && data.success && data.data && data.data.length > 0) {
            const overview = data.data.find(d => d.type === 'overview');
            if (overview && overview.data) {
                const details = overview.data.find(l => l.layout_type === 'details');
                if (details && details.layout_data && details.layout_data[0]) {
                    const realDesc = details.layout_data[0].description;
                    overviewContainer.innerHTML = `<div class="overview-content">${realDesc || 'No description provided.'}</div>`;
                    return; 
                }
            }
        }
        overviewContainer.innerHTML = '<p style="color: var(--text-muted); font-weight: 600;">No overview available for this batch.</p>';
    } catch(e) {
        overviewContainer.innerHTML = '<p class="text-danger">Failed to load overview from API.</p>';
    }
}

window.closeCourse = function() { 
    document.getElementById('detail-view').style.display = 'none'; 
    document.getElementById('main-app').style.display = 'block'; 
}

// ==========================================
// 3. LIVE FEED
// ==========================================
async function fetchLiveFeed(courseId) {
    const liveContainer = document.getElementById('live-list-container');
    const liveSection = document.getElementById('live-section');
    if(!liveSection) return;

    liveSection.style.display = 'block';
    liveContainer.innerHTML = '<div class="text-center py-5"><i class="fas fa-circle-notch fa-spin fa-2x text-danger mb-3"></i><br><span style="color:var(--text-muted); font-weight: 600;">Intercepting Live Matrix...</span></div>';

    try {
        let potentialClasses = [];
        let scannedFolders = new Set(); 

        async function scanFolderTree(fId, depth) {
            if(depth > 5 || scannedFolders.has(fId)) return;
            scannedFolders.add(fId);

            try {
                const data = await engineFetch(API.CONTENT, 'POST', { course_id: String(courseId), folder_id: String(fId), limit: "5000", page: "1", parent_course_id: "0" });
                let items = (data && data.data) ? (Array.isArray(data.data) ? data.data : (Array.isArray(data.data.list) ? data.data.list : [])) : [];

                let subFolders = [];

                for (let item of items) {
                    const type = (item.type || "").toLowerCase();
                    const d = item.data || {};
                    const id = d.id || item.entity_id || item.id;
                    let vType = parseInt(item.video_type || d.video_type || 0);

                    if (vType === 3 || type === 'live' || parseInt(d.is_live) === 1 || parseInt(item.is_live) === 1) {
                        item.parent_folder_id = fId; 
                        potentialClasses.push(item);
                    } else if (type === 'folder' || type === 'subject' || type === 'chapter') {
                        subFolders.push(id);
                    }
                }
                await Promise.all(subFolders.map(subId => scanFolderTree(subId, depth + 1)));
            } catch (e) {}
        }

        await scanFolderTree("0", 1);

        let confirmedLives = [];
        const now = Date.now();

        await Promise.all(potentialClasses.map(async (item) => {
            const id = item.data?.id || item.entity_id || item.id;
            const trueDataRes = await engineFetch(`${API.MEDIA}?content_id=${id}&course_id=${courseId}`, 'GET', null);
            
            if (trueDataRes && trueDataRes.success && trueDataRes.data) {
                let trueMedia = trueDataRes.data;
                let liveFrom = parseInt(trueMedia.live_from || 0) * 1000;
                let timeDiffHours = (now - liveFrom) / (1000 * 60 * 60);

                if (timeDiffHours < 24 || parseInt(trueMedia.is_live) === 1 || parseInt(trueMedia.live_status) === 1 || parseInt(trueMedia.live_status) === 2) {
                    item.true_media = trueMedia;
                    confirmedLives.push(item);
                }
            }
        }));

        confirmedLives.sort((a, b) => parseInt(a.true_media.live_from || 0) - parseInt(b.true_media.live_from || 0));

        if (confirmedLives.length === 0) { 
            liveContainer.innerHTML = `<div class="text-center py-4" style="background: rgba(255,255,255,0.02); border-radius: 12px; border: 1px dashed var(--border-color);"><p style="color: var(--text-muted); font-weight: 600; margin: 0;">No upcoming live classes right now.</p></div>`;
            return; 
        }

        let html = '';

        confirmedLives.forEach(item => {
            const trueMedia = item.true_media;
            const id = trueMedia.id;
            const safeTitle = encodeURIComponent(trueMedia.title || item.title || "Live Class");
            const thumb = trueMedia.thumbnail || item.thumbnail || FALLBACK_IMG;
            
            let rawSeconds = parseInt(trueMedia.live_from || 0);
            let dateString = formatIST(rawSeconds);
            let timeStr = getTimeDiffStr(rawSeconds);

            let isCurrentlyLive = false;
            if (parseInt(item.is_live) === 1 || parseInt(item.data?.is_live) === 1 || parseInt(trueMedia.is_live) === 1 || parseInt(trueMedia.live_status) === 1 || parseInt(trueMedia.live_status) === 2) {
                isCurrentlyLive = true;
            }

            let tagHtml = ''; let btnHtml = '';

            if (isCurrentlyLive) {
                tagHtml = '<span class="adv-tag tag-live-now"><i class="fas fa-circle" style="font-size: 8px; margin-right: 4px;"></i>LIVE NOW</span>';
                btnHtml = `<button class="adv-btn adv-btn-danger" onclick="executeMediaAction('${id}', '${safeTitle}', true, this)"><i class="fas fa-satellite-dish"></i> Join Live</button>`;
            } 
            else {
                tagHtml = `<span class="adv-tag tag-scheduled">🕒 SCHEDULED</span>`;
                btnHtml = `<button class="adv-btn adv-btn-outline" disabled><i class="fas fa-lock"></i> Starts in ${timeStr}</button>`;
            }

            html += `
            <div class="adv-folder-item animate-slide-up">
                <img src="${thumb}" class="adv-item-thumb" onerror="this.src='${FALLBACK_IMG}'">
                <div class="adv-item-info">
                    <h5 class="adv-item-title" title="${trueMedia.title || item.title}">${trueMedia.title || item.title} ${tagHtml}</h5>
                    <small style="color: var(--primary); font-weight:600; font-size: 12px;"><i class="far fa-clock"></i> Scheduled For: ${dateString}</small>
                </div>
                <div class="adv-item-actions">${btnHtml}</div>
            </div>`;
        });
        
        liveContainer.innerHTML = html;
    } catch(e) {
        liveContainer.innerHTML = '<p class="text-danger text-center font-weight-bold">Live feed intercept error. Please reload.</p>';
    }
}

        // ==========================================
// 4. VOD CONTENT FOLDERS (Strict Backend Routing)
// ==========================================
window.fetchFolderContent = async function(folderId) {
    const listDiv = document.getElementById('content-list');
    listDiv.innerHTML = "<div class='text-center py-5'><i class='fas fa-circle-notch fa-spin fa-2x text-primary'></i><p class='mt-3' style='color: var(--text-muted); font-weight: 600;'>Syncing Vault...</p></div>";
    
    const navDiv = document.getElementById('folder-nav');
    if (navDiv) {
        navDiv.innerHTML = folderHistory.length > 1 
            ? `<button style="background:transparent; border:none; color:var(--primary); font-weight:700; cursor:pointer; padding:0; display:flex; align-items:center; gap:8px; margin-bottom:15px; font-size: 14px; transition: 0.3s;" onmouseover="this.style.opacity=0.8" onmouseout="this.style.opacity=1" onclick="folderHistory.pop(); fetchFolderContent(folderHistory[folderHistory.length-1].id);"><i class="fas fa-arrow-left"></i> Go Back</button> <h5 style="color: var(--text-main); font-weight:800; display: flex; align-items: center; gap: 8px;"><i class="fas fa-folder-open" style="color: #f59e0b;"></i> ${folderHistory[folderHistory.length-1].name}</h5>` 
            : "";
    }

    const payload = { course_id: String(currentCourseId), folder_id: String(folderId), is_free: "", keyword: "", limit: "1000", page: "1", parent_course_id: "0" };
    const data = await engineFetch(API.CONTENT, 'POST', payload);
    listDiv.innerHTML = "";
    
    let items = [];
    if (data && data.data) {
        if (Array.isArray(data.data)) items = data.data;
        else if (Array.isArray(data.data.list)) items = data.data.list;
    }

    if(items.length === 0) { 
        listDiv.innerHTML = `<div class="text-center py-5"><i class="fas fa-folder-open fa-3x mb-3" style="color: var(--border-color);"></i><p style="color: var(--text-muted); font-size: 16px; font-weight: 600;">Folder is empty.</p></div>`; 
        return; 
    }

    let html = '';

    items.forEach((item, idx) => {
        const type = (item.type || "").toLowerCase();
        const d = item.data || {};
        const isFolder = type === 'folder' || type === 'subject' || type === 'chapter';
        const isTest = type === 'test' || type === 'quiz';
        
        const safeTitle = (item.title || "Untitled").replace(/'/g, "\\'");
        const encodedTitle = encodeURIComponent(item.title || "Untitled");
        const thumb = item.thumbnail || d.thumbnail || FALLBACK_IMG;
        const contentId = d.id || item.entity_id || item.id;

        let vType = parseInt(item.video_type || d.video_type || 0);
        let fileType = parseInt(item.file_type || d.file_type || 0);
        let isVideo = type === 'video' || fileType === 2 || vType === 3;

        let rawSeconds = parseInt(item.live_from || d.live_from || item.created_at || d.created_at || 0);
        let dateString = formatIST(rawSeconds);
        let timeStr = getTimeDiffStr(rawSeconds);
        
        let isCurrentlyLive = (parseInt(item.is_live) === 1 || parseInt(d.is_live) === 1 || parseInt(item.live_status) === 1 || parseInt(d.live_status) === 1 || parseInt(item.live_status) === 2);

        let liveTag = ''; let btnText = ''; let btnIcon = '';
        let routeToLiveHTML = false; let isBtnDisabled = false;

        if (vType === 3) {
            if (isCurrentlyLive) {
                liveTag = ' <span class="adv-tag tag-live-now"><i class="fas fa-circle" style="font-size: 8px; margin-right: 4px;"></i>LIVE NOW</span>';
                btnText = 'Join Live'; btnIcon = "fa-satellite-dish"; routeToLiveHTML = true; 
            } else {
                liveTag = ` <span class="adv-tag tag-scheduled">🕒 SCHEDULED</span>`;
                btnText = `Starts in ${timeStr}`; btnIcon = "fa-lock"; routeToLiveHTML = false; isBtnDisabled = true;
            }
        } else if (isVideo) {
            liveTag = ' <span class="adv-tag tag-recorded">RECORDED</span>';
            btnText = 'Watch Recording'; btnIcon = "fa-play-circle"; routeToLiveHTML = false; 
        } else {
            btnText = 'Open Content'; btnIcon = "fa-external-link-alt";
        }

        let badgeText = isFolder ? 'Folder' : (routeToLiveHTML ? 'Live Session' : (isVideo ? 'Video' : (isTest ? 'Test' : 'Document')));
        let dateHtml = rawSeconds > 0 ? `<div style="margin-top: 6px;"><small style="color: var(--primary); font-weight:600; font-size:12px;"><i class="far fa-clock"></i> Scheduled: ${dateString}</small></div>` : "";

        let actionHtml = '';
        if (isFolder) {
            actionHtml = `<button class="adv-btn adv-btn-primary" onclick="folderHistory.push({id:'${contentId}', name:'${safeTitle}'}); fetchFolderContent('${contentId}');"><i class="fas fa-folder-open"></i> Open Folder</button>`;
        } else if (isBtnDisabled) {
            actionHtml = `<button class="adv-btn adv-btn-outline" disabled><i class="fas ${btnIcon}"></i> ${btnText}</button>`;
        } else {
            // STRICT ROUTING: All media must go through the backend decryptor
            let btnClassToUse = routeToLiveHTML ? "adv-btn-danger" : "adv-btn-primary";
            actionHtml = `<button class="adv-btn ${btnClassToUse}" onclick="executeMediaAction('${contentId}', '${encodedTitle}', ${routeToLiveHTML}, this)"><i class="fas ${btnIcon}"></i> ${btnText}</button>`;
        }
        
        html += `
            <div class="adv-folder-item animate-slide-up" style="animation-delay: ${idx * 0.05}s;">
                <img src="${thumb}" class="adv-item-thumb" onerror="this.src='${FALLBACK_IMG}'">
                <div class="adv-item-info">
                    <h5 class="adv-item-title" title="${item.title}">${item.title}${liveTag}</h5>
                    <span style="background: var(--bg-color); border: 1px solid var(--border-color); color: var(--text-muted); font-size: 11px; padding: 4px 10px; border-radius: 6px; font-weight:700; display:inline-block; margin-top:4px;">${badgeText}</span>
                    ${dateHtml}
                </div>
                <div class="adv-item-actions">${actionHtml}</div>
            </div>`;
    });
    listDiv.innerHTML = html;
}
// ==========================================
// 5. SNIPER MEDIA FETCHER (BACKEND ROUTING)
// ==========================================
window.executeMediaAction = async function(contentId, title, forceLiveRoute, btnElement) {
    const orgHtml = btnElement ? btnElement.innerHTML : "";
    if(btnElement) {
        btnElement.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Fetching Stream...';
        btnElement.disabled = true;
    }

    try {
        // 🚨 UPDATE THIS URL TO MATCH YOUR VERCEL DEPLOYMENT 🚨
        const CUSTOM_BACKEND_URL = `https://sp-api-five.vercel.app/api/content-details`;
        
        const exactApiUrl = `${CUSTOM_BACKEND_URL}?content_id=${contentId}&course_id=${currentCourseId}`;
        
        // Call the backend, passing the VIP headers so the backend can use the fresh token
        const response = await fetch(exactApiUrl, {
            method: 'GET',
            headers: NT_HEADERS
        });
        
        const data = await response.json();
        
        if(btnElement) {
            btnElement.innerHTML = orgHtml;
            btnElement.disabled = false;
        }

        if (!data || !data.success || !data.data) { 
            alert("Backend rejected the request. Token might be expired or firewall blocked."); 
            console.error("Backend Response:", data);
            return; 
        }

        // Backend returned the clean JSON
        const mediaData = data.data;
        
        let mediaUrl = mediaData.file_url || "";
        let videoType = parseInt(mediaData.video_type || 0);
        let fileType = parseInt(mediaData.file_type || 0);
        const safeTitle = encodeURIComponent(decodeURIComponent(title));
        
        // Extract from download_urls if file_url is missing
        if (!mediaUrl && mediaData.download_urls && mediaData.download_urls !== '""') { 
            try { 
                const videoSources = typeof mediaData.download_urls === 'string' 
                    ? JSON.parse(mediaData.download_urls) 
                    : mediaData.download_urls; 

                if (videoSources && videoSources.length > 0) {
                    mediaUrl = videoSources[videoSources.length - 1].url;
                    
                    // Format standard download links to native HLS streams
                    if (mediaUrl && mediaUrl.includes('/download/')) {
                        mediaUrl = mediaUrl.replace('/download/', '/channel_vod_non_drm_hls/');
                        if (!mediaUrl.endsWith('.m3u8')) mediaUrl += '.m3u8';
                    }
                }
            } catch(e) {
                console.error("Failed to parse download links:", e);
            } 
        }

        // Route to appropriate player
        if (forceLiveRoute || videoType === 3) {
            let chatNode = mediaData.mqtt_live_cred ? (mediaData.mqtt_live_cred.public_chat_node || "") : "";
            const safeStream = encodeURIComponent(mediaUrl);
            window.open(`live.html?title=${safeTitle}&node=${chatNode}&stream=${safeStream}&videoId=${contentId}`, '_blank');
            return;
        }

        if (mediaUrl) {
            if (mediaUrl.toLowerCase().endsWith('.pdf') || fileType === 3 || fileType === 1) {
                window.open(mediaUrl, '_blank');
            } else if (videoType === 1 || mediaUrl.includes('youtube.com') || mediaUrl.includes('youtu.be')) {
                let ytId = mediaUrl.includes('v=') ? mediaUrl.split('v=')[1].substring(0, 11) : mediaUrl.split('youtu.be/')[1].substring(0, 11);
                window.open(`https://www.youtube.com/watch?v=${ytId}`, '_blank');
            } else {
                window.open(`player.html?url=${encodeURIComponent(mediaUrl)}&title=${safeTitle}`, '_blank');
            }
        } else { 
            alert("No playable media URL found in the content details."); 
        }
    } catch(e) {
        if(btnElement) { btnElement.innerHTML = orgHtml; btnElement.disabled = false; }
        alert("Failed to connect to the backend engine.");
        console.error("Engine Error:", e);
    }
}

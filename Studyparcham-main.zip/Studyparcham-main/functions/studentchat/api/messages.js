export async function onRequest(context) {
  const { request, env } = context;

  try {
    if (!env.SSP_DB) {
      return new Response(JSON.stringify({ error: "SSP_DB is not bound in Cloudflare settings" }), { status: 500 });
    }

    if (request.method === "GET") {
      const { results } = await env.SSP_DB.prepare("SELECT * FROM student_messages ORDER BY id ASC").all();
      return new Response(JSON.stringify(results), { headers: { "Content-Type": "application/json" } });
    }

    if (request.method === "POST") {
      const data = await request.json();
      await env.SSP_DB.prepare("INSERT INTO student_messages (username, message, file_data, file_name, file_type) VALUES (?, ?, ?, ?, ?)")
        .bind(data.username || "Student", data.message || "", data.fileData || null, data.fileName || null, data.fileType || null).run();
      return new Response(JSON.stringify({ success: true }), { headers: { "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });

  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

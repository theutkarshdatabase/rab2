export async function onRequest(context) {
  const { request, env } = context;

  try {
    if (!env.SSP_DB) {
      return new Response(JSON.stringify({ error: "SSP_DB is not bound" }), { status: 500 });
    }

    if (request.method === "POST") {
      const data = await request.json();
      
      // Backend security check: only delete if the password matches
      if (data.password !== "uthuspsf") {
        return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 403 });
      }

      await env.SSP_DB.prepare("DELETE FROM student_messages WHERE id = ?").bind(data.id).run();
      return new Response(JSON.stringify({ success: true }), { headers: { "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });

  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

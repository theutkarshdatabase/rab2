export async function onRequest(context) {
  const { request, env } = context;

  try {
    if (!env.SSP_DB) {
      return new Response(JSON.stringify({ error: "SSP_DB is not bound in Cloudflare settings" }), { status: 500 });
    }

    if (request.method === "GET") {
      const { results } = await env.SSP_DB.prepare("SELECT * FROM notifications ORDER BY id ASC").all();
      return new Response(JSON.stringify(results), { headers: { "Content-Type": "application/json" } });
    }

    if (request.method === "POST") {
      const data = await request.json();
      if (data.password !== "uthuspsf") {
        return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 403 });
      }

      await env.SSP_DB.prepare("INSERT INTO notifications (username, message, file_data, file_name, file_type) VALUES (?, ?, ?, ?, ?)")
        .bind("Admin", data.message || "", data.fileData || null, data.fileName || null, data.fileType || null).run();
      return new Response(JSON.stringify({ success: true }), { headers: { "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });

  } catch (err) {
    // This catches the exact error so it doesn't throw a blank 1101 page
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

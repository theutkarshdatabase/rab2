export async function onRequestPost(context) {
  const { request, env } = context;
  const data = await request.json();
  await env.DB.prepare("DELETE FROM messages WHERE id = ?").bind(data.id).run();
  return new Response(JSON.stringify({ success: true }), { headers: { "Content-Type": "application/json" } });
}

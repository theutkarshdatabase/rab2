export async function onRequest(context) {
  const { request, env } = context;
  
  if (request.method === "GET") {
    const { results } = await env.DB.prepare("SELECT * FROM messages ORDER BY id ASC").all();
    return new Response(JSON.stringify(results), { headers: { "Content-Type": "application/json" } });
  }
  
  if (request.method === "POST") {
    const data = await request.json();
    await env.DB.prepare("INSERT INTO messages (username, message, file_data, file_name, file_type) VALUES (?, ?, ?, ?, ?)")
      .bind(data.username || "Anonymous", data.message || "", data.fileData || null, data.fileName || null, data.fileType || null).run();
    return new Response(JSON.stringify({ success: true }), { headers: { "Content-Type": "application/json" } });
  }
}

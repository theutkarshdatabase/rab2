export async function onRequest(context) {
    const { request } = context;

    // 🚀 1. CORS PREFLIGHT (Allows your frontend to talk to this proxy)
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*', // You can change this to 'https://studyparcham.in' to lock it down
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
    };

    if (request.method === 'OPTIONS') {
        return new Response(null, { headers: corsHeaders });
    }

    if (request.method !== 'POST') {
        return Response.json(
            { success: false, message: "Method Not Allowed. Use POST." }, 
            { status: 405, headers: corsHeaders }
        );
    }

    try {
        // Grab the incoming payload from your frontend
        const input = await request.json();

        // 2. Build the Exact Payload StudySpark Expects
        const sparkPayload = {
            batchId: input.batchId || "",
            childId: input.childId || "",
            turnstileToken: input.turnstileToken || "",
            live: input.live || false
        };

        // 3. The Master Headers (Injecting their API keys and tokens)
        const sparkHeaders = new Headers({
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Referer": "https://studyspark.study/",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",
            "sec-ch-ua": '"Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "x-api-key": "ghop-ghop-ghop-36516",
            "x-auth-token": "baap-bol-338495",
            "x-client-info": Date.now().toString(), // Always fresh timestamp
            "x-fingerprint": "onel76"
        });

        // 4. Execute the Stealth Fetch
        const response = await fetch('https://api.studyspark.study/api/video-link', {
            method: 'POST',
            headers: sparkHeaders,
            body: JSON.stringify(sparkPayload)
        });

        const rawText = await response.text();

        // 5. Parse and Return securely to your UI
        try {
            const cleanJson = JSON.parse(rawText);
            return Response.json(cleanJson, { headers: corsHeaders });
        } catch (parseError) {
            // Fallback just in case they return raw HTML or a firewall block
            return new Response(rawText, { 
                status: response.status, 
                headers: { ...corsHeaders, "Content-Type": "text/plain" } 
            });
        }

    } catch (error) {
        return Response.json(
            { success: false, message: "Proxy Execution Error", error: error.message }, 
            { status: 500, headers: corsHeaders }
        );
    }
}

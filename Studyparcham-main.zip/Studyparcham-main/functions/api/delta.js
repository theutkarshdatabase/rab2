export async function onRequest(context) {
    const { request } = context;

    // 1. Handle CORS Preflight (Bypass the block)
    if (request.method === "OPTIONS") {
        return new Response(null, {
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        });
    }

    const urlObj = new URL(request.url);
    let targetUrl = urlObj.searchParams.get('url') || urlObj.searchParams.get('path');

    if (!targetUrl) {
        return Response.json({ error: "No URL provided" }, { status: 400, headers: { "Access-Control-Allow-Origin": "*" } });
    }

    let fetchMethod = request.method;
    let fetchBody = request.method !== 'GET' && request.method !== 'HEAD' ? await request.text() : undefined;
    
    let headers = new Headers();
    headers.set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/122.0.0.0 Safari/537.36");

    // 2. THE MAGIC: Automatically convert /live GET requests to POST (Mirrors your proxy.php)
    if (targetUrl.includes('/api/pw/live') || targetUrl.includes('/live?batchId=')) {
        fetchMethod = "POST";
        const targetUrlObj = new URL(targetUrl);
        const batchId = targetUrlObj.searchParams.get('batchId');
        if (batchId) {
            fetchBody = JSON.stringify({ batchId: batchId });
            headers.set("Content-Type", "application/json");
        }
    } else if (request.headers.has("Content-Type")) {
         headers.set("Content-Type", request.headers.get("Content-Type"));
    }

    try {
        // 3. Fetch the data directly from the target
        const response = await fetch(targetUrl, {
            method: fetchMethod,
            headers: headers,
            body: fetchBody
        });

        // 4. Pure CORS Bypass - Return exactly what was received without breaking it!
        const respText = await response.text();
        
        return new Response(respText, {
            status: response.status,
            headers: { 
                "Content-Type": response.headers.get("Content-Type") || "application/json", 
                "Access-Control-Allow-Origin": "*" 
            }
        });

    } catch (e) {
        return Response.json({ error: e.message }, { status: 500, headers: { "Access-Control-Allow-Origin": "*" } });
    }
}

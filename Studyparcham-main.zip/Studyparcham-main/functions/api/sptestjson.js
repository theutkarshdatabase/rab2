// functions/api/sptestjson.js

export async function onRequest(context) {
    const { request } = context;
    const url = new URL(request.url);

    // 1. Extract parameters from the frontend request
    const batchid = url.searchParams.get('batchid') || '';
    const testname = url.searchParams.get('testname') || 'Test';
    const testid = url.searchParams.get('testid') || '';
    const source = url.searchParams.get('source') || 'dpp';
    const batchScheduleId = url.searchParams.get('batchScheduleId') || '';
    const subjectId = url.searchParams.get('subjectId') || '';

    // 2. Build the secure Thor URL
    const targetUrl = `https://pwthor.live/api/gettestjson?batchid=${batchid}&testname=${encodeURIComponent(testname)}&testid=${testid}&source=${source}&batchScheduleId=${batchScheduleId}&subjectId=${subjectId}`;

    try {
        // 3. Fetch from Thor using heavy Anti-Bot Spoofing Headers
        const response = await fetch(targetUrl, {
            method: 'GET',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Referer': 'https://pwthor.live/',
                'Origin': 'https://pwthor.live',
                'Accept-Language': 'en-US,en;q=0.9'
            }
        });

        // 4. Read as text first to prevent JSON parse crashes if Cloudflare blocks it
        const text = await response.text();

        let jsonResponse;
        try {
            jsonResponse = JSON.parse(text);
        } catch (e) {
            // If it fails to parse, it means Thor sent an HTML block page
            return new Response(JSON.stringify({
                success: false,
                message: "Thor API blocked the proxy request (Cloudflare Bot Fight Mode).",
                raw: text.substring(0, 200)
            }), {
                status: 403,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                }
            });
        }

        // 5. Send the clean JSON back to dpp.html with open CORS
        return new Response(JSON.stringify(jsonResponse), {
            status: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            }
        });

    } catch (err) {
        return new Response(JSON.stringify({ success: false, error: err.message }), {
            status: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
    }
}

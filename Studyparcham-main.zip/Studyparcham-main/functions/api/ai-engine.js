export async function onRequestPost(context) {
    const { request } = context;

    try {
        const input = await request.json();
        const chatHistory = input.history || [];
        const batchContext = input.batches || 'Batch data currently unavailable.';

        if (chatHistory.length === 0) {
            return Response.json({ reply: 'Error: Message history is empty' });
        }

        const systemPrompt = `You are the official AI Tutor for 'StudyParcham', a futuristic ed-tech platform. 
Core Platform Knowledge:
1. 'pw': The platform the student is currently on.
2. 'NextToppers': Our second platform where they got all nexttopers batches for free.
3. 'MissionJeet': Our related powerful app for extreme exam preparation for jee and neet, in this platform all batches of drona in free.

CRITICAL INSTRUCTION: If the student asks to find, load, open, or search for a specific batch (or subject), you MUST include the exact tag [SEARCH: Keyword] at the end of your response.

Currently Available Batches on pw zero:
[${batchContext}]

Instructions: Help the student with academic doubts or batch queries. Answer deeply and completely without worrying about length. Formatted nicely, and encouraging. and also if any student ask for any thing help him.`;

        const payload = {
            system_instruction: {
                parts: [{ text: systemPrompt }]
            },
            contents: chatHistory,
            generationConfig: {
                maxOutputTokens: 8192
            }
        };

         const API_KEYS = [
            'AQ.Ab8RN6Lh2uBgtjMEKl0y' + '5g_GoJ6diHJdsxEFUJCHqCU8bmVUIA'
            ];

        let aiText = 'Network Error. AI is currently offline.';
        let success = false;

        // 🎯 Loop through the keys. If one is rate-limited (429), instantly try the next!
        for (const key of API_KEYS) {
            const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`;
            
            try {
                const response = await fetch(API_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                const json = await response.json();

                // 🎯 If Google throws a 429 Quota Exceeded error, skip to the next key!
                if (!response.ok && json.error) {
                    if (json.error.code === 429) {
                        continue; 
                    } else {
                        // It's a different error (like bad format), report it
                        aiText = 'StudyParcham AI Error: ' + json.error.message;
                        break; 
                    }
                }

                // Success! Extract the text and stop the loop
                if (json.candidates && json.candidates[0].content && json.candidates[0].content.parts) {
                    aiText = json.candidates[0].content.parts[0].text;
                    success = true;
                    break; 
                }
            } catch (fetchError) {
                continue; // Skip to next key if network fetch completely fails
            }
        }

        // Fallback message if ALL keys are exhausted or blocked
        if (!success && aiText === 'Network Error. AI is currently offline.') {
            aiText = 'All AI servers are currently busy processing too many requests. Please try again in 60 seconds!';
        }

        return Response.json({ reply: aiText });

    } catch (e) {
        return Response.json({ reply: 'Server processing error.' });
    }
}

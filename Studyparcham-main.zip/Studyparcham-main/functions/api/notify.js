export async function onRequestPost(context) {
    const { request, env } = context;
    
    const ONESIGNAL_APP_ID = "c7b1128d-2b7d-47b7-8d7f-d73485b9be0b";
    const ONESIGNAL_REST_KEY = "os_v2_app_y6yrfdjlpvd3pdl7242ilon6bnqqczdnuqgu2v5jh3dmhjdto5d77ko6aqmwttkshw72jztldpeja4owuumqi4e4skvlp254woixwyy";
    const DOMAIN = "studyparcham.im";

    try {
        const payload = await request.json();
        if (!payload || !payload.batches || !Array.isArray(payload.batches)) {
            return Response.json({ success: false, message: "Invalid payload." }, { status: 400 });
        }

        // Limit to 4 to prevent Edge timeouts
        const batchIds = payload.batches.slice(0, 4);
        
        // Get cache from KV database
        let cache = {};
        if (env.PW_KV) {
            cache = await env.PW_KV.get('notif_cache', { type: 'json' }) || {};
        }

        let updatesSent = 0;

        for (const batch of batchIds) {
            // Using your Vercel Proxy
            const targetUrl = `https://api.penpencil.co/v1/batches/${batch.id}/announcement?page=1&limit=10`;
            const proxyUrl = `https://pw-proxy-sp.vercel.app/api/proxy?target_url=${encodeURIComponent(targetUrl)}`;
            
            const res = await fetch(proxyUrl);
            if (!res.ok) continue;
            
            const data = await res.json();
            
            if (data && data.data && Array.isArray(data.data)) {
                const announcements = data.data.reverse();
                if (!cache[batch.id]) cache[batch.id] = [];

                for (const notif of announcements) {
                    const notifId = notif._id;
                    
                    if (!cache[batch.id].includes(notifId)) {
                        let imageUrl = "";
                        if (notif.attachment && notif.attachment.key) {
                            imageUrl = notif.attachment.baseUrl + notif.attachment.key;
                        }

                        let messageText = notif.announcement.replace(/<[^>]*>?/gm, ''); // Basic strip tags

                        const osPayload = {
                            app_id: ONESIGNAL_APP_ID,
                            filters: [{ field: 'tag', key: 'pw_batch_id', relation: '=', value: batch.id }],
                            headings: { en: "PW: " + (notif.heading || "New Update") },
                            contents: { en: messageText },
                            url: `https://${DOMAIN}/`
                        };

                        if (imageUrl) {
                            osPayload.big_picture = imageUrl;
                            osPayload.ios_attachments = { id1: imageUrl };
                        }

                        // Send to OneSignal
                        await fetch("https://onesignal.com/api/v1/notifications", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json; charset=utf-8",
                                "Authorization": "Basic " + ONESIGNAL_REST_KEY
                            },
                            body: JSON.stringify(osPayload)
                        });

                        cache[batch.id].push(notifId);
                        if (cache[batch.id].length > 30) cache[batch.id].shift();
                        updatesSent++;
                    }
                }
            }
        }

        // Save updated memory back to KV
        if (env.PW_KV) {
            await env.PW_KV.put('notif_cache', JSON.stringify(cache));
        }

        return Response.json({ success: true, updatesSent: updatesSent });

    } catch (e) {
        return Response.json({ success: false, message: e.message }, { status: 500 });
    }
}

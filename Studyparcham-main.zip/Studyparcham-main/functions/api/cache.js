export async function onRequest(context) {
    const { request, env } = context;

    // 1. Setup CORS so Add.html can talk to this worker
    const corsHeaders = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Content-Type": "application/json"
    };

    // Handle preflight requests
    if (request.method === "OPTIONS") {
        return new Response(null, { headers: corsHeaders });
    }

    try {
        const formData = await request.formData();
        const action = formData.get('action');
        const batchIdsRaw = formData.get('batch_ids') || '';

        if (action !== 'fetch_batch' || !batchIdsRaw) {
            return Response.json({ success: false, error: "Invalid payload parameters" }, { headers: corsHeaders });
        }

        // Clean up the comma-separated IDs into an array
        const targetIds = batchIdsRaw.split(',').map(id => id.trim()).filter(Boolean);
        
        let syncedCount = 0;
        let failedCount = 0;

        // 2. Load the current KV Cache so we don't overwrite existing batches
        let currentKVCache = [];
        const existingData = await env.PW_KV.get('batches_cache');
        if (existingData) {
            try { currentKVCache = JSON.parse(existingData); } catch(e) { currentKVCache = []; }
        }

        // Map it so we can easily prevent duplicates
        let cacheMap = new Map(currentKVCache.map(item => [item.id || item._id, item]));

        // 3. Loop through the requested IDs and fetch directly from PW Servers
        for (let batchId of targetIds) {
            try {
                // 🎯 FIXED: Direct raw server-to-server fetch instead of using frontend ParchamCore!
                const pwRes = await fetch(`https://api.penpencil.co/v3/batches/${batchId}/details`, {
                    headers: {
                        "Client-Id": "5eb393ee95fab7468a79d189",
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                    }
                });
                
                const pwJson = await pwRes.json();
                let rawBatch = pwJson.data;

                // If the fetch was successful and we got data
                if (rawBatch && (rawBatch.name || rawBatch._id)) {
                    
                    // Extract precise image links safely
                    let finalizedThumb = "https://store.pw.live/footer-logo.svg";
                    if (rawBatch.previewImage) {
                        if (typeof rawBatch.previewImage === 'string') {
                            finalizedThumb = rawBatch.previewImage;
                        } else if (rawBatch.previewImage.baseUrl && rawBatch.previewImage.key) {
                            finalizedThumb = rawBatch.previewImage.baseUrl + rawBatch.previewImage.key;
                        }
                    }

                    // 🛡️ SHREDDER: Compress data into your lightweight blueprint
                    const compressedBatch = {
                        id: rawBatch._id || batchId,
                        imageUrl: finalizedThumb,
                        name: rawBatch.name || "Custom PW Batch"
                    };

                    cacheMap.set(compressedBatch.id, compressedBatch);
                    syncedCount++;
                } else {
                    failedCount++; // ID not found on PW servers
                }
            } catch(err) {
                console.error("Fetch failed for ID:", batchId, err);
                failedCount++;
            }
        }

        // 4. Save the combined updated array back to Cloudflare KV
        const updatedCacheArray = Array.from(cacheMap.values());
        await env.PW_KV.put('batches_cache', JSON.stringify(updatedCacheArray));

        return Response.json({
            success: true,
            batches_synced_this_run: syncedCount,
            batches_failed: failedCount,
            total_batches_in_cache: updatedCacheArray.length
        }, { headers: corsHeaders });

    } catch (e) {
        return Response.json({ success: false, error: e.message }, { headers: corsHeaders });
    }
}
